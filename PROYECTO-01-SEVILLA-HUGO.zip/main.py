from lifestore_file import lifestore_products as products, lifestore_sales as sales, lifestore_searches as searches
from operator import itemgetter
from collections import Counter
import os
import numpy as np
from copy import deepcopy
from tabulate import tabulate

usuarios = [['Hugo', '123', 'Admin'], ['Paco', '456', 'No Admin'], ['Luis','789', 'Admin'], ['Cesar', '321', 'No Admin']]

opcion = ''
usuario = input('Ingresa nombre de usuario: ')
password = input('Ingresa contraseña de usuario: ')

os.system('cls' if os.name == 'nt' else 'clear')

admins = list(filter(lambda x: str(x[2]) == 'Admin', usuarios))
nombres_todos = list(map(itemgetter(0), usuarios)) 
nombres_admins = list(map(itemgetter(0), admins))

inicio_sesion = 'No'
if usuario in nombres_todos:
  if usuario in nombres_admins:
    usuario_encontrado = [usuario, password, 'Admin']
    if usuario_encontrado in usuarios:
      print('Inicio de sesión exitoso, BIENVENIDO.')
      inicio_sesion = 'Si'
    else:
      print('Contraseña incorrecta. Programa finalizado. Adiós.')
  else:
    print('Usuario indentificado, pero no es Administrador. Programa Finalizado. Adiós.')
else:
  print('No Existe Usuario. Programa Finalizado. Adiós.')
  opcion = 0

# Listado de Productos de más búsquedas
busquedas_producto = list(map(itemgetter(1), searches))
nombres_productos = list(map(itemgetter(1), products))

categorias_productos = list(map(itemgetter(3), products))
categorias_unicas = np.unique(categorias_productos)
categorias_unicas = list(map(lambda el:[el], categorias_unicas)) # separar en lista de listas

busquedas = dict(Counter(busquedas_producto))
busquedas_copia = busquedas.copy()
busquedas_categoria = []

for busqueda in busquedas:
  busqueda_nombre = nombres_productos[int(busqueda)]
  llave_nueva = busqueda_nombre
  llave_vieja = busqueda
  busquedas_copia[llave_nueva] = busquedas_copia.pop(llave_vieja)

busquedas = busquedas_copia.copy()
busquedas_copia.clear()

busquedas_ordenadas = sorted(busquedas.items(), key=lambda x: x[1], reverse=True)

# Listado de los Productos con más Ventas

compras_producto = list(map(itemgetter(1), sales))
compras = dict(Counter(compras_producto))

compras_copia = compras.copy()
for compra in compras:
  compra_nombre = nombres_productos[int(compra)]
  llave_nueva = compra_nombre
  llave_vieja = compra
  compras_copia[llave_nueva] = compras_copia.pop(llave_vieja)

compras = compras_copia.copy()
compras_copia.clear()
compras_ordenadas = sorted(compras.items(), key=lambda x: x[1], reverse=True)

categorias_unicas_ventas = categorias_unicas.copy()

# Lista en reversa
for venta in compras_ordenadas[::-1]:
  for producto in products:
    if producto[1] == venta[0]:
      if producto[3] == 'audifonos':
        categorias_unicas_ventas[0].append(venta);
      elif producto[3] == 'bocinas':
        categorias_unicas_ventas[1].append(venta);
      elif producto[3] == 'discos duros':
        categorias_unicas_ventas[2].append(venta);
      elif producto[3] == 'memorias usb':
        categorias_unicas_ventas[3].append(venta);
      elif producto[3] == 'pantallas':
        categorias_unicas_ventas[4].append(venta)
      elif producto[3] == 'procesadores':
        categorias_unicas_ventas[5].append(venta);
      elif producto[3] == 'tarjetas de video':
        categorias_unicas_ventas[6].append(venta);
      elif producto[3] == 'tarjetas madre':
        categorias_unicas_ventas[7].append(venta);
      break;

categorias_unicas_busquedas = categorias_unicas.copy()
# Lista en reversa
for busqueda in compras_ordenadas[::-1]:
  for producto in products:
    if producto[1] == busqueda[0]:
      if producto[3] == 'audifonos':
        categorias_unicas_busquedas[0].append(busqueda);
      elif producto[3] == 'bocinas':
        categorias_unicas_busquedas[1].append(busqueda);
      elif producto[3] == 'discos duros':
        categorias_unicas_busquedas[2].append(busqueda);
      elif producto[3] == 'memorias usb':
        categorias_unicas_busquedas[3].append(busqueda);
      elif producto[3] == 'pantallas':
        categorias_unicas_busquedas[4].append(busqueda)
      elif producto[3] == 'procesadores':
        categorias_unicas_busquedas[5].append(busqueda);
      elif producto[3] == 'tarjetas de video':
        categorias_unicas_busquedas[6].append(busqueda);
      elif producto[3] == 'tarjetas madre':
        categorias_unicas_busquedas[7].append(busqueda);
      break;

# Listas de 20 productos con mejores y peores reseñas

ventas_por_calificacion = deepcopy(sales) # para que la copia no afecte la original

reviews_por_producto = []

contador = 0
for review in ventas_por_calificacion:

  review_puntos = review[2] #+ (review[4]*(-5))
  producto_review = nombres_productos[review[1]-1]
  
  #reviews_por_producto.append([[producto_review], [review_puntos]])
  reviews_por_producto.append([[producto_review], [review_puntos], [review[4]]])

  contador +=1

productos_reviewed = []

for producto_review in reviews_por_producto:
  productos_reviewed.append(producto_review[0])

productos_reviewed_unicos = list(np.unique(productos_reviewed))
productos_reviewed_unicos_puntuados = deepcopy(productos_reviewed_unicos)
productos_reviewed_unicos_puntuados = list(map(lambda el:[el], productos_reviewed_unicos_puntuados))

contador = 0
for producto in productos_reviewed_unicos_puntuados:
  productos_reviewed_unicos_puntuados[contador].append(0)
  productos_reviewed_unicos_puntuados[contador].append(0)
  contador += 1

"""
"""
contador = 0
for review in reviews_por_producto:
  reviewed_nombre = review[0][0]
  reviewed_calificacion = review[1][0]
  devuelto = review[2][0]

  reviewed_index = productos_reviewed_unicos.index(reviewed_nombre)

  # sumar calificacion
  productos_reviewed_unicos_puntuados[reviewed_index][1] += reviewed_calificacion
  # sumar devueltos
  productos_reviewed_unicos_puntuados[reviewed_index][2] += devuelto

  contador += 1

# invertir valores para itemgetter
contador = 0
for producto in productos_reviewed_unicos_puntuados:
  productos_reviewed_unicos_puntuados[contador][2] = - (producto[2])
  contador += 1

# Ordenar lista de listas
productos_reviewed_unicos_puntuados = sorted(productos_reviewed_unicos_puntuados, key=itemgetter(1, 2))
 
 # invertir valores después itemgetter
contador = 0
for producto in productos_reviewed_unicos_puntuados:
  productos_reviewed_unicos_puntuados[contador][2] = - (producto[2])
  contador += 1


"""
os.system('cls' if os.name == 'nt' else 'clear')

sales = [id_sale, id_product, score (from 1 to 5), date, refund (1 for true or 0 to false)]
products = [id_product, name, price, category, stock]

"""

# Mesos ingresos, ventas y anual
meses_ingresos_totales = [0] * 12
meses_ingresos_cantidad = [0] * 12
meses_ventas_totales = [0] * 12
meses_ventas_cantidad = [0] * 12

#meses_ventas = [0] * 12
#meses_ventas = list(map(lambda el:[el], meses_ventas))

for venta in sales:
  id_producto = venta[1]
  mes = int(venta[3][3:5])
  precio = products[id_producto][2]
  devuelto = venta[4]
  
  meses_ventas_totales[mes-1] += precio 
  meses_ventas_cantidad[mes-1] += 1

  if devuelto == 0:
    meses_ingresos_totales[mes-1] += precio
    meses_ingresos_cantidad[mes-1] += 1

meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']

total_anual = sum(meses_ingresos_totales)

promedios = []
for i in range(12):

  if meses_ventas_cantidad[i] == 0:
    promedio = 0
  else:
    promedio = meses_ventas_totales[i]/meses_ventas_cantidad[i]

  promedios.append([meses[i], meses_ingresos_totales[i],promedio, meses_ventas_totales[i]])

while(opcion != 8):

  opcion = input('Ingrese lo que quiera analizar:\n1: Listado de Productos con mayores ventas\n2: Listado de productos con mayores búsquedas\n3: Listado de productos con menores ventas separados por categoría.\n4: Listado de productos con menores busquedas separados por categoría.\n5: Listado de 20 productos con peores calificaciones de reseñas - tomando en cuenta devoluciones\n6: Listado de 20 productos con mejores calificaciones de reseñas - tomando en cuenta devoluciones\n7: Total de ingresos, ventas promedio y ventas totales mensuales & ventas anuales\n8: Salir\nRespuesta: ')
  os.system('cls' if os.name == 'nt' else 'clear')

  if opcion == '1':
    print('PRODUCTOS MÁS VENDIDOS:\n')
    for venta in compras_ordenadas:
      if venta[1] != 1:
        print('Venta de producto: "'+ venta[0]+'". Realizada:',venta[1],'veces.\n')
      else:
        print('Venta de producto: "'+ venta[0]+'". Realizada:',venta[1],'vez.\n')

  elif opcion == '2':
    print('PRODUCTOS MÁS BUSCADOS:\n')
    for busqueda in busquedas_ordenadas:
      if busqueda[1] != 1:
        print('Búsqueda de producto: "'+ busqueda[0]+'". Realizada:',busqueda[1],'veces.\n')
      else:
        print('Búsqueda de producto: "'+ busqueda[0]+'". Realizada:',busqueda[1],'vez.\n')
      #print(products.index(busqueda[0]))

  elif opcion == '3':
    print('PRODUCTOS MENOS VENDIDOS - POR CATEGORÍA:\n')
    for venta in categorias_unicas_ventas:
      contador = 0
      for venta_unica in venta:
        if contador != 0:
          if venta_unica[1] != 1:
            print ('Producto: "'+venta_unica[0]+'." Vendido:',venta_unica[1],'veces.')
          else:
            print ('Producto: "'+venta_unica[0]+'." Vendido:',venta_unica[1],'vez.')
        else:
          print ('CATEGORÍA:',venta_unica)
        contador += 1
      print()

  elif opcion == '4':
    print('PRODUCTOS MENOS BUSCADOS - POR CATEGORÍA:\n')
    for busqueda in categorias_unicas_busquedas:
      contador = 0
      for busqueda_unica in busqueda:
        if contador != 0:
          if busqueda_unica[1] != 1:
            print ('Producto: "'+busqueda_unica[0]+'." Buscado:',busqueda_unica[1],'veces.')
          else:
            print ('Producto: "'+busqueda_unica[0]+'." Buscado:',busqueda_unica[1],'vez.')
        else:
          print ('CATEGORÍA:',busqueda_unica,'\n')
        contador += 1
      print()

  elif opcion == '5':
    print('LISTA DE 20 PRODUCTOS CON PEOR CALIFICACIÓN DE RESEÑAS - TOMANDO EN CUENTA DEVOLUCIONES:\n')
    contador = 1
    for producto in productos_reviewed_unicos_puntuados[:20]:
      print(str(contador)+' - Producto: "'+str(producto[0])+'". Con una puntuación de reseñas de: '+str(producto[1])+'. y una cantidad de devolucion(es) de: '+ str(producto[2])+'\n' )
      contador += 1

  elif opcion == '6':
    print('LISTA DE 20 PRODUCTOS CON MEJOR CALIFICACIÓN DE RESEÑAS - TOMANDO EN CUENTA DEVOLUCIONES:\n')
    contador = 1
    for producto in productos_reviewed_unicos_puntuados[:-21:-1]:
      print(str(contador)+' - Producto: "'+str(producto[0])+'". Con una puntuación de reseñas de: '+str(producto[1])+'. y una cantidad de devolucion(es) de: '+ str(producto[2])+'\n' )
      contador += 1

  elif opcion == '7':
    print('Total de ingresos, ventas promedio y ventas totales mensuales:\n')

    print(tabulate(promedios, headers=['Mes', 'Total de Ingresos', 'Ventas Promedio', 'Ventas Totales'], tablefmt="fancy_grid"))
    print('Total anual = ${:,.2f}'.format(total_anual),'\n')
  elif opcion == '8':
    print('Programa Finalizado. Adiós.')
    break;
  else:
    print('Opción inexistente, Ingrese una opción correcta...\n')
  
  input ('\'Click \"ENTER\"  Key to Continue\'')
  os.system('cls' if os.name == 'nt' else 'clear')